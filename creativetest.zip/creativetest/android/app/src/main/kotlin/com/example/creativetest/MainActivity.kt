package com.example.creativetest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
